const data = require('../data/posts.json');
let totalImgs = 0, withImg = 0, noImg = [];
for (const p of data.posts) {
  const m = (p.content.match(/<img/g) || []).length;
  totalImgs += m;
  if (m > 0) withImg++; else noImg.push(p.id);
}
console.log('total imgs:', totalImgs, '| posts with imgs:', withImg, '| without:', noImg.join(','));
const p1 = data.posts.find(p => p.id === 1);
console.log('id=1 has other-drive:', /UC网盘|drive\.uc|移动云盘|quark|xunlei|115/i.test(p1.content));
console.log('id=1 last 300:', p1.content.slice(-300));
console.log('any loading.gif left:', data.posts.some(p => /loading\.gif/.test(p.content)));
console.log('any lazy left:', data.posts.some(p => /class="lazy"/.test(p.content)));
