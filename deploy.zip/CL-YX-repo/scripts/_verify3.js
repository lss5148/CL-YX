const data = require('../data/posts.json');
let totalImgs = 0, withImg = 0, noImg = [];
for (const p of data.posts) {
  const m = (p.content.match(/<img/g) || []).length;
  totalImgs += m;
  if (m > 0) withImg++; else noImg.push(p.id);
}
console.log('total imgs:', totalImgs, '| posts with imgs:', withImg, '| without:', noImg.join(','));
console.log('any loading.gif left:', data.posts.some(p => /loading\.gif/.test(p.content)));
// 检查双 src
let doubleSrc = 0;
for (const p of data.posts) {
  if (/<img[^>]*src="[^"]*"\s+src="/.test(p.content)) doubleSrc++;
}
console.log('posts with double src:', doubleSrc);
