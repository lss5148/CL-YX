const https = require('https');
const cheerio = require('cheerio');
function get(url) {
  return new Promise((res, rej) => {
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, r => {
      if (r.statusCode >= 300 && r.statusCode < 400) return get(r.headers.location).then(res, rej);
      let d = '';
      r.on('data', c => d += c);
      r.on('end', () => res(d));
    }).on('error', rej);
  });
}
(async () => {
  const tests = [
    { id: 4, url: 'https://www.acgyxjvip2.com/4937.html' }, // will patch below
  ];
  const posts = require('../data/posts.json');
  for (const p of posts.posts) {
    if (p.id === 4 || p.id === 5 || p.id === 8 || p.id === 15) {
      const html = await get(p.source);
      const $ = cheerio.load(html);
      const c = $('.single-content').first();
      const imgs = c.find('img').length;
      const paras = c.find('p').length;
      const textLen = c.text().trim().length;
      console.log('id=' + p.id, '| imgs:', imgs, '| paras:', paras, '| textlen:', textLen, '| title:', p.title.substring(0, 50));
    }
  }
})().catch(e => console.error(e.message));
