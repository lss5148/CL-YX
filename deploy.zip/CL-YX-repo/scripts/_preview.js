const data = require('../data/posts.json');
console.log('总数:', data.posts.length);
let totalImgs = 0, withImg = 0, withBody = 0;
for (const p of data.posts) {
  totalImgs += (p.content.match(/<img/g) || []).length;
  if (/<img[\s>]/.test(p.content)) withImg++;
  const body = p.content.replace(/<hr>[\s\S]*$/, '').replace(/<hr>/g, '');
  const textLen = body.replace(/<[^>]+>/g, '').trim().length;
  if (textLen > 50) withBody++;
}
console.log('内文有图片的:', withImg, '| 有正文文字的:', withBody, '| 图片总数:', totalImgs);
console.log('残留 loading.gif:', data.posts.some(p => /loading\.gif/.test(p.content)));
console.log('残留其他网盘:', data.posts.some(p => /UC网盘|移动云盘|pan\.quark|pan\.xunlei|drive\.uc|caiyun\.139/i.test(p.content)));
// 抽 3 篇看正文摘要
for (const id of [1, 4, 28]) {
  const p = data.posts.find(x => x.id === id);
  const body = (p.content || '').replace(/<hr>[\s\S]*$/, '');
  const text = body.replace(/<img[^>]*>/g, '[图]').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  console.log('\n--- id=' + id + ' ' + p.title.substring(0, 40));
  console.log(text.substring(0, 300) + '…');
}
