const data = require('../data/posts.json');
for (const p of data.posts) {
  if (/loading\.gif/.test(p.content)) {
    const m = p.content.match(/<img[^>]*loading\.gif[^>]*>/g);
    console.log('gif in id=' + p.id, m ? m.slice(0, 1).join('') : '');
  }
}
