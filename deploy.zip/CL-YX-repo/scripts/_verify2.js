const data = require('../data/posts.json');
for (const id of [1, 4, 5, 8, 9]) {
  const p = data.posts.find(x => x.id === id);
  const m = p.content.match(/<img[^>]*>/g);
  console.log('id=' + id, m ? m.slice(0, 2).join(' | ') : '(no img)');
}
// check which post still has loading.gif
for (const p of data.posts) {
  if (/loading\.gif/.test(p.content)) {
    const m = p.content.match(/<img[^>]*loading\.gif[^>]*>/g);
    console.log('gif in id=' + p.id, m ? m.slice(0, 1).join(' ') : '');
  }
}
